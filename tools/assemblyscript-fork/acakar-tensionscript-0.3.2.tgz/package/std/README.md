Standard library
================

Standard library components for use with `tsc` (portable) and `tensionscript` (assembly).

Base configurations (.json) and definition files (.d.ts) are relevant to `tsc` only and not used by `tensionscript`.
